import 'package:flutter/material.dart';

class ChatBoot extends StatefulWidget {
  ChatBoot({Key? key}) : super(key: key);

  @override
  State<ChatBoot> createState() => _ChatBootState();
}

class _ChatBootState extends State<ChatBoot> {
 @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Text('Coming Soon'),
      ),
    );
  }
}