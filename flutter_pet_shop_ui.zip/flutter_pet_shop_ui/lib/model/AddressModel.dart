
class AddressModel{

  int? id;


  String? location;
  String? name;
  String? phoneNumber;
  String? type;


}