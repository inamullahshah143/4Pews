class DataModel{


   String? image;


   DataModel(this.image, this.name);

  String? name;


}