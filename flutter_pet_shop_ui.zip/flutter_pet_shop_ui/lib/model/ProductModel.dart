class ProductModel {
  String? image;
  String? icon;
  String? price;
  String? offerPrice;
  String? subTitle;

  String? desc;
  String? subText;
  String? name;
  String? address;
  int quantity = 1;

}
