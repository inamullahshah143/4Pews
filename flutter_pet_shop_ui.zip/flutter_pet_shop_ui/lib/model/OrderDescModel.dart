class OrderDescModel{


  String? name;
  String? desc;
  int? completed;
}