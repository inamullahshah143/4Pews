class PaymentModel{
  String? name;
  String? image;
  bool? isCash=false;
}