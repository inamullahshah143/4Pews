
import 'dart:ui';

class IntroModel{

  int? id;


  String? image;
  String? name;
  String? desc;
  Color? color;
  Color? endColor;


}