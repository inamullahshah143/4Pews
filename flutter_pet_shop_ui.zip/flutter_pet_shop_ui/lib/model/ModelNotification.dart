class ModelNotification {
  String title;
  String desc;

  ModelNotification(this.title, this.desc);
}
