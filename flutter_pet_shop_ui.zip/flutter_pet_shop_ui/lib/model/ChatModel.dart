class ChatModel{



  String image;
  String name;
  String lastMessage;
  String date;
  String time;
  String desc="It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.";
  int active;

  ChatModel(this.name, this.image,this.active,this.lastMessage,this.time,this.date);

}