## 2.0.8

* Split from `shared_preferences` as a federated implementation.
