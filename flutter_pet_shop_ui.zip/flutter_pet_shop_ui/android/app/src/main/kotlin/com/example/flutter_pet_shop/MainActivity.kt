package com.example.flutter_pet_shop

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
